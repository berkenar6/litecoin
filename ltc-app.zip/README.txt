HOW TO USE:

1. Upload this folder to GitHub
2. Import project into Vercel
3. Deploy
4. Open link on iPhone Safari
5. Tap Share -> Add to Home Screen

DONE.
